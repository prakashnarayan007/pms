package pim.person;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;
public class PersonDBService {
	Connection con;
	
	
	public PersonDBService()
	{
		DBConnectionDTO conDTO = new DBConnectionDTO();
		con=conDTO.getConnection();
	}
	
	public void closeConnection()
	{
		try {
			con.close();
		}
		catch (Exception e) {
			System.out.println(e);
		}
	}
public int getTotalPages(int limit)
	{
		String query="select count(*) from person_detail";
	    int totalRecords=0;
	    int totalPages=0;
		try {
		Statement stmt = con.createStatement();
	    ResultSet rs = stmt.executeQuery(query);
	    if(rs.next()) {
	    	totalRecords= rs.getInt(1);
	    }
	    stmt.close();
	    rs.close();
		}
		catch (Exception e) {
			System.out.println(e);
		}
		totalPages=totalRecords/limit;
		if(totalRecords%limit!=0)
		{
			totalPages+=1;
		}
		return totalPages;
	}
	
	//pagination
	public int getTotalPages(Person person,int limit)
	{
		String query=getDynamicQuery2(person);
		int totalRecords=0;
	    int totalPages=0;
		try {
		Statement stmt = con.createStatement();
	    ResultSet rs = stmt.executeQuery(query);
	    if(rs.next()) {
	    	totalRecords= rs.getInt(1);
	    }
	    stmt.close();
	    rs.close();
		}
		catch (Exception e) {
			System.out.println(e);
		}
		totalPages=totalRecords/limit;
		if(totalRecords%limit!=0)
		{
			totalPages+=1;
		}
		return totalPages;
	}
	
	
	public int getPersonId(Person person)
	{
		int id=0;
		String query="select id from person_detail";
String whereClause = " where "+ "uname=? and password=? and email=? and mobileNo=? and gender=? and dob=? and age=? and state=? and address=?";
	    query+=whereClause;
		System.out.println(query);
		try {
PreparedStatement pstmt = con.prepareStatement(query);
pstmt.setString(1, person.getUname());
pstmt.setString(2, person.getPassword());
pstmt.setString(3, person.getEmail());
pstmt.setString(4, person.getMobileNo());
pstmt.setString(5, person.getGender());
pstmt.setDate(6, java.sql.Date.valueOf(DateService.getDTSYYYMMDDFormat(person.getDob())));
pstmt.setInt(7, person.getAge());
pstmt.setString(8, person.getState());
pstmt.setString(9, person.getAddress());
	    ResultSet rs = pstmt.executeQuery();
	    if(rs.next()) {
	       	id = rs.getInt("id");
	    }
		}
	    catch (Exception e) {
	    	System.out.println(e);
		}
	    
	    return id;
	}
	public void createPerson(Person person)
	{
		
String query="INSERT INTO person_detail(uname,password,email,mobileNo,gender,dob,age,state,address) VALUES(?,?,?,?,?,?,?,?,?)";
	
    System.out.println(query);
		try {
PreparedStatement pstmt = con.prepareStatement(query);
pstmt.setString(1, person.getUname());
pstmt.setString(2, person.getPassword());
pstmt.setString(3, person.getEmail());
pstmt.setString(4, person.getMobileNo());
pstmt.setString(5, person.getGender());
pstmt.setDate(6, java.sql.Date.valueOf(DateService.getDTSYYYMMDDFormat(person.getDob())));
pstmt.setInt(7, person.getAge());
pstmt.setString(8, person.getState());
pstmt.setString(9, person.getAddress());
	    int x = pstmt.executeUpdate();
	    }
	    catch (Exception e) {
	  
  	System.out.println(e);
		}
		int id = getPersonId(person);
		person.setId(id);
	}
	public void updatePerson(Person person)
	{
		
String query="update person_detail set "+"uname=?,password=?,email=?,mobileNo=?,gender=?,dob=?,age=?,state=?,address=? where id=?";
	   
 System.out.println(query);
		try {
PreparedStatement pstmt = con.prepareStatement(query);
pstmt.setString(1, person.getUname());
pstmt.setString(2, person.getPassword());
pstmt.setString(3, person.getEmail());
pstmt.setString(4, person.getMobileNo());
pstmt.setString(5, person.getGender());
pstmt.setDate(6, java.sql.Date.valueOf(DateService.getDTSYYYMMDDFormat(person.getDob())));
pstmt.setInt(7, person.getAge());
pstmt.setString(8, person.getState());
pstmt.setString(9, person.getAddress());
pstmt.setInt(10, person.getId());
	    int x = pstmt.executeUpdate();
	    }
	    catch (Exception e) {
	    	System.out.println(e);
		}
		
	}
	public String getValue(String code,String table) {
		
		String value="";
		String query="select value from "+table+" where code='"+code+"'";
	    System.out.println(query);
		try {
		Statement stmt = con.createStatement();
	    ResultSet rs = stmt.executeQuery(query);
	    if(rs.next()) {
	    	
	    	value=rs.getString("value");
	    }
		}
		catch (Exception e) {
			System.out.println(e);
		}
	    return value;
	}
	
	public Person getPerson(int id)
	{
		Person person =new Person();
		String query="select * from person_detail where id="+id;
	    System.out.println(query);
		try {
		Statement stmt = con.createStatement();
	    ResultSet rs = stmt.executeQuery(query);
	    if(rs.next()) {
	    	
	
person.setId(rs.getInt("id")==0?0:rs.getInt("id"));
person.setUname(rs.getString("uname")==null?"":rs.getString("uname"));
person.setPassword(rs.getString("password")==null?"":rs.getString("password"));
person.setEmail(rs.getString("email")==null?"":rs.getString("email"));
person.setMobileNo(rs.getString("mobileNo")==null?"":rs.getString("mobileNo"));
person.setGender(rs.getString("gender")==null?"":rs.getString("gender"));
person.setGenderValue(rs.getString("gender")==null?"":getValue(rs.getString("gender"),"gender_detail"));
person.setDob(DateService.getDTDYYYYMMDDFormat(rs.getDate("dob")==null?DateService.getDefaultDtYYYYMMDD():rs.getDate("dob")));
person.setAge(rs.getInt("age")==0?0:rs.getInt("age"));
person.setAgeValue(rs.getString("age")==null?"":getValue(rs.getString("age"),"status"));
person.setState(rs.getString("state")==null?"":rs.getString("state"));
person.setStateValue(rs.getString("state")==null?"":getValue(rs.getString("state"),"state_detail"));
person.setAddress(rs.getString("address")==null?"":rs.getString("address"));
	    	
	    }
		}
	    catch (Exception e) {
	    	System.out.println(e);
		}
	    
	    return person;
	}
	
	
	public ArrayList<Person> getPersonList()
	{
		ArrayList<Person> personList =new ArrayList<Person>();
		String query="select * from person_detail";
	    System.out.println(query);
		try {
		Statement stmt = con.createStatement();
	    ResultSet rs = stmt.executeQuery(query);
	    while(rs.next()) {
	    	Person person =new Person();
person.setId(rs.getInt("id")==0?0:rs.getInt("id"));
person.setUname(rs.getString("uname")==null?"":rs.getString("uname"));
person.setPassword(rs.getString("password")==null?"":rs.getString("password"));
person.setEmail(rs.getString("email")==null?"":rs.getString("email"));
person.setMobileNo(rs.getString("mobileNo")==null?"":rs.getString("mobileNo"));
person.setGender(rs.getString("gender")==null?"":rs.getString("gender"));
person.setGenderValue(rs.getString("gender")==null?"":getValue(rs.getString("gender"),"gender_detail"));
person.setDob(DateService.getDTDYYYYMMDDFormat(rs.getDate("dob")==null?DateService.getDefaultDtYYYYMMDD():rs.getDate("dob")));
person.setAge(rs.getInt("age")==0?0:rs.getInt("age"));
person.setAgeValue(rs.getString("age")==null?"":getValue(rs.getString("age"),"status"));
person.setState(rs.getString("state")==null?"":rs.getString("state"));
person.setStateValue(rs.getString("state")==null?"":getValue(rs.getString("state"),"state_detail"));
person.setAddress(rs.getString("address")==null?"":rs.getString("address"));
	    	personList.add(person);
	    }
		}
	    catch (Exception e) {
	    	System.out.println(e);
		}
	    
	    return personList;
	}
	
	public ArrayList<Person> getPersonList(int pageNo,int limit)
	{
		ArrayList<Person> personList =new ArrayList<Person>();
String query="select * from person_detail limit "+limit +" offset "+limit*(pageNo-1);
	    System.out.println(query);
		try {
		Statement stmt = con.createStatement();
	    ResultSet rs = stmt.executeQuery(query);
	    while(rs.next()) {
	    	Person person =new Person();
person.setId(rs.getInt("id")==0?0:rs.getInt("id"));
person.setUname(rs.getString("uname")==null?"":rs.getString("uname"));
person.setPassword(rs.getString("password")==null?"":rs.getString("password"));
person.setEmail(rs.getString("email")==null?"":rs.getString("email"));
person.setMobileNo(rs.getString("mobileNo")==null?"":rs.getString("mobileNo"));
person.setGender(rs.getString("gender")==null?"":rs.getString("gender"));
person.setGenderValue(rs.getString("gender")==null?"":getValue(rs.getString("gender"),"gender_detail"));
person.setDob(DateService.getDTDYYYYMMDDFormat(rs.getDate("dob")==null?DateService.getDefaultDtYYYYMMDD():rs.getDate("dob")));
person.setAge(rs.getInt("age")==0?0:rs.getInt("age"));
person.setAgeValue(rs.getString("age")==null?"":getValue(rs.getString("age"),"status"));
person.setState(rs.getString("state")==null?"":rs.getString("state"));
person.setStateValue(rs.getString("state")==null?"":getValue(rs.getString("state"),"state_detail"));
person.setAddress(rs.getString("address")==null?"":rs.getString("address"));
	    	personList.add(person);
	    }
		}
	    catch (Exception e) {
	    	System.out.println(e);
		}
	    
	    return personList;
	}
	
	public void deletePerson(int id) {
		
			String query="delete from person_detail where id="+id;
		    System.out.println(query);
				
			
		    try {
			Statement stmt = con.createStatement();
		    int x = stmt.executeUpdate(query);
		    }
		    catch (Exception e) {
		    	System.out.println(e);
			}
		
	}
	
public String getDynamicQuery(Person person)
{
String query="select * from person_detail ";
String whereClause="";
whereClause+=(null==person.getEmail()||person.getEmail().equals(""))?"":" email='"+person.getEmail()+"'";
if(whereClause.equals(""))
whereClause+=(null==person.getGender()||person.getGender().equals(""))?"":" gender='"+person.getGender()+"'";
else
whereClause+=(null==person.getGender()||person.getGender().equals(""))?"":" and gender='"+person.getGender()+"'";
if(whereClause.equals(""))
whereClause+=(null==person.getDobFrom()||DateService.getDTSYYYMMDDFormat(person.getDobFrom()).equals("1111-11-11"))?"":" (dob between '"+DateService.getDTSYYYMMDDFormat(person.getDobFrom())+"' and '"+DateService.getDTSYYYMMDDFormat(person.getDobTo())+"')";
else
whereClause+=(null==person.getDobFrom()||DateService.getDTSYYYMMDDFormat(person.getDobFrom()).equals("1111-11-11"))?"":" and (dob between '"+DateService.getDTSYYYMMDDFormat(person.getDobFrom())+"' and '"+DateService.getDTSYYYMMDDFormat(person.getDobTo())+"')";
if(whereClause.equals(""))
whereClause+=(person.getAge()==0?"":" age="+person.getAge());
else
whereClause+=(person.getAge()==0?"":" and age="+person.getAge());
if(whereClause.equals(""))
whereClause+=(null==person.getState()||person.getState().equals(""))?"":" state='"+person.getState()+"'";
else
whereClause+=(null==person.getState()||person.getState().equals(""))?"":" and state='"+person.getState()+"'";
if(!whereClause.equals(""))
query+=" where "+whereClause;
System.out.println("Search Query= "+query);
    return query;
}
public String getDynamicQuery2(Person person)
{
String query="select count(*) from person_detail ";
String whereClause="";
whereClause+=(null==person.getEmail()||person.getEmail().equals(""))?"":" email='"+person.getEmail()+"'";
if(whereClause.equals(""))
whereClause+=(null==person.getGender()||person.getGender().equals(""))?"":" gender='"+person.getGender()+"'";
else
whereClause+=(null==person.getGender()||person.getGender().equals(""))?"":" and gender='"+person.getGender()+"'";
if(whereClause.equals(""))
whereClause+=(null==person.getDobFrom()||DateService.getDTSYYYMMDDFormat(person.getDobFrom()).equals("1111-11-11"))?"":" (dob between '"+DateService.getDTSYYYMMDDFormat(person.getDobFrom())+"' and '"+DateService.getDTSYYYMMDDFormat(person.getDobTo())+"')";
else
whereClause+=(null==person.getDobFrom()||DateService.getDTSYYYMMDDFormat(person.getDobFrom()).equals("1111-11-11"))?"":" and (dob between '"+DateService.getDTSYYYMMDDFormat(person.getDobFrom())+"' and '"+DateService.getDTSYYYMMDDFormat(person.getDobTo())+"')";
if(whereClause.equals(""))
whereClause+=(person.getAge()==0?"":" age="+person.getAge());
else
whereClause+=(person.getAge()==0?"":" and age="+person.getAge());
if(whereClause.equals(""))
whereClause+=(null==person.getState()||person.getState().equals(""))?"":" state='"+person.getState()+"'";
else
whereClause+=(null==person.getState()||person.getState().equals(""))?"":" and state='"+person.getState()+"'";
if(!whereClause.equals(""))
query+=" where "+whereClause;
System.out.println("Search Query= "+query);
    return query;
}
public ArrayList<Person> getPersonList(Person person)
{
ArrayList<Person> personList =new ArrayList<Person>();
String query=getDynamicQuery(person);
System.out.println("Search Query= "+query);
try {
Statement stmt = con.createStatement();
ResultSet rs = stmt.executeQuery(query);
while(rs.next()) {
Person person2 =new Person();
person2.setId(rs.getInt("id")==0?0:rs.getInt("id"));
person2.setUname(rs.getString("uname")==null?"":rs.getString("uname"));
person2.setPassword(rs.getString("password")==null?"":rs.getString("password"));
person2.setEmail(rs.getString("email")==null?"":rs.getString("email"));
person2.setMobileNo(rs.getString("mobileNo")==null?"":rs.getString("mobileNo"));
person2.setGender(rs.getString("gender")==null?"":rs.getString("gender"));
person2.setGenderValue(rs.getString("gender")==null?"":getValue(rs.getString("gender"),"gender_detail"));
person2.setDob(DateService.getDTDYYYYMMDDFormat(rs.getDate("dob")==null?DateService.getDefaultDtYYYYMMDD():rs.getDate("dob")));
person2.setAge(rs.getInt("age")==0?0:rs.getInt("age"));
person2.setAgeValue(rs.getString("age")==null?"":getValue(rs.getString("age"),"status"));
person2.setState(rs.getString("state")==null?"":rs.getString("state"));
person2.setStateValue(rs.getString("state")==null?"":getValue(rs.getString("state"),"state_detail"));
person2.setAddress(rs.getString("address")==null?"":rs.getString("address"));
    	personList.add(person2);
    }
	}
    catch (Exception e) {
    	System.out.println(e);
	}
    return personList;
}
	
public ArrayList<Person> getPersonList(Person person,int pageNo,int limit)
{
ArrayList<Person> personList =new ArrayList<Person>();
String query=getDynamicQuery(person);
query+= " limit "+limit +" offset "+limit*(pageNo-1);
System.out.println("Search Query= "+query);
try {
Statement stmt = con.createStatement();
ResultSet rs = stmt.executeQuery(query);
while(rs.next()) {
Person person2 =new Person();
person2.setId(rs.getInt("id")==0?0:rs.getInt("id"));
person2.setUname(rs.getString("uname")==null?"":rs.getString("uname"));
person2.setPassword(rs.getString("password")==null?"":rs.getString("password"));
person2.setEmail(rs.getString("email")==null?"":rs.getString("email"));
person2.setMobileNo(rs.getString("mobileNo")==null?"":rs.getString("mobileNo"));
person2.setGender(rs.getString("gender")==null?"":rs.getString("gender"));
person2.setGenderValue(rs.getString("gender")==null?"":getValue(rs.getString("gender"),"gender_detail"));
person2.setDob(DateService.getDTDYYYYMMDDFormat(rs.getDate("dob")==null?DateService.getDefaultDtYYYYMMDD():rs.getDate("dob")));
person2.setAge(rs.getInt("age")==0?0:rs.getInt("age"));
person2.setAgeValue(rs.getString("age")==null?"":getValue(rs.getString("age"),"status"));
person2.setState(rs.getString("state")==null?"":rs.getString("state"));
person2.setStateValue(rs.getString("state")==null?"":getValue(rs.getString("state"),"state_detail"));
person2.setAddress(rs.getString("address")==null?"":rs.getString("address"));
    	personList.add(person2);
    }
	}
    catch (Exception e) {
    	System.out.println(e);
	}
    return personList;
}
	
	
	public static void main(String[] args) {
		
		PersonDBService personDBService =new PersonDBService();
		
		
		
		 //Test-1 : Create Person
		  
		  Person person = new Person(); person.setDefaultValues();
		  personDBService.createPerson(person);
		  
		 ArrayList<Person> personList = personDBService.getPersonList();
		PersonService personService =new PersonService();
		personService.displayList(personList);
		
	}
}
