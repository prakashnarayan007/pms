package pim.person;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

public class Person {
 
int id;
String uname;
String password;
String email;
String mobileNo;
String gender;
String genderValue;
Date dob;
Date dobFrom;
Date dobTo;
int age;
String ageValue;
String state;
String stateValue;
String address;

public int getId()
{
return id;
}
public void setId(int id)
{
this.id=id;
}
public String getUname()
{
return uname;
}
public void setUname(String uname)
{
this.uname=uname;
}
public String getPassword()
{
return password;
}
public void setPassword(String password)
{
this.password=password;
}
public String getEmail()
{
return email;
}
public void setEmail(String email)
{
this.email=email;
}
public String getMobileNo()
{
return mobileNo;
}
public void setMobileNo(String mobileNo)
{
this.mobileNo=mobileNo;
}
public String getGender()
{
return gender;
}
public String getGenderValue()
{
return genderValue;
}
public void setGender(String gender)
{
this.gender=gender;
}
public void setGenderValue(String genderValue)
{
this.genderValue = genderValue;
}
public Date getDob()
{
return dob;
}
public Date getDobFrom()
{
return dobFrom;
}
public Date getDobTo()
{
return dobTo;
}
public void setDob(Date dob)
{
this.dob=dob;
}
public void setDobFrom(Date dobFrom)
{
this.dobFrom=dobFrom;
}
public void setDobTo(Date dobTo)
{
this.dobTo=dobTo;
}
public int getAge()
{
return age;
}
public String getAgeValue()
{
return ageValue;
}
public void setAge(int age)
{
this.age=age;
}
public void setAgeValue(String ageValue)
{
this.ageValue = ageValue;
}
public String getState()
{
return state;
}
public String getStateValue()
{
return stateValue;
}
public void setState(String state)
{
this.state=state;
}
public void setStateValue(String stateValue)
{
this.stateValue = stateValue;
}
public String getAddress()
{
return address;
}
public void setAddress(String address)
{
this.address=address;
}


public void setRequestParam(HttpServletRequest request) {

this.setId(null!=request.getParameter("id")&&!request.getParameter("id").equals("")?Integer.parseInt((String)request.getParameter("id")):0);
this.setUname(null!=request.getParameter("uname")?request.getParameter("uname"):"");
this.setPassword(null!=request.getParameter("password")?request.getParameter("password"):"");
this.setEmail(null!=request.getParameter("email")?request.getParameter("email"):"");
this.setMobileNo(null!=request.getParameter("mobileNo")?request.getParameter("mobileNo"):"");
this.setGender(null!=request.getParameter("gender")?request.getParameter("gender"):"");
this.setDob(null!=request.getParameter("dob")&&!request.getParameter("dob").equals("")?DateService.getSTDYYYYMMDDFormat(request.getParameter("dob")):DateService.getSTDYYYYMMDDFormat("11-11-1111"));
this.setDobFrom(null!=request.getParameter("dobFrom")&&!request.getParameter("dobFrom").equals("")?DateService.getSTDYYYYMMDDFormat(request.getParameter("dobFrom")):DateService.getSTDYYYYMMDDFormat("11-11-1111"));
this.setDobTo(null!=request.getParameter("dobTo")&&!request.getParameter("dobTo").equals("")?DateService.getSTDYYYYMMDDFormat(request.getParameter("dobTo")):DateService.getSTDYYYYMMDDFormat("11-11-1111"));
this.setAge(null!=request.getParameter("age")&&!request.getParameter("age").equals("")?Integer.parseInt((String)request.getParameter("age")):0);
this.setState(null!=request.getParameter("state")?request.getParameter("state"):"");
this.setAddress(null!=request.getParameter("address")?request.getParameter("address"):"");

}

public void displayReqParam(HttpServletRequest request) {


System.out.println("------Begin:Request Param Values---------");
System.out.println("id = "+request.getParameter("id"));
System.out.println("uname = "+request.getParameter("uname"));
System.out.println("password = "+request.getParameter("password"));
System.out.println("email = "+request.getParameter("email"));
System.out.println("mobileNo = "+request.getParameter("mobileNo"));
System.out.println("gender = "+request.getParameter("gender"));
System.out.println("dob = "+request.getParameter("dob"));
System.out.println("dobFrom = "+request.getParameter("dobFrom"));
System.out.println("dobTo = "+request.getParameter("dobTo"));
System.out.println("age = "+request.getParameter("age"));
System.out.println("state = "+request.getParameter("state"));
System.out.println("address = "+request.getParameter("address"));

System.out.println("------End:Request Param Values---------");
}

public void displayValues() {

System.out.println("Id = "+this.getId());
System.out.println("Uname = "+this.getUname());
System.out.println("Password = "+this.getPassword());
System.out.println("Email = "+this.getEmail());
System.out.println("MobileNo = "+this.getMobileNo());
System.out.println("Gender = "+this.getGender());
System.out.println("Dob = "+DateService.getDTSYYYMMDDFormat(this.getDob()));
System.out.println("DobFrom = "+DateService.getDTSYYYMMDDFormat(this.getDobFrom()));
System.out.println("DobTo = "+DateService.getDTSYYYMMDDFormat(this.getDobTo()));
System.out.println("Age = "+this.getAge());
System.out.println("State = "+this.getState());
System.out.println("Address = "+this.getAddress());

}

public void setDefaultValues() {

this.setUname("");
this.setPassword("");
this.setEmail("");
this.setMobileNo("");
this.setGender("");
this.setDob(DateService.getSTDYYYYMMDDFormat("11-11-1111"));
this.setDobFrom(DateService.getSTDYYYYMMDDFormat("11-11-1111"));
this.setDobTo(DateService.getSTDYYYYMMDDFormat("11-11-1111"));
this.setAge(0);
this.setState("");
this.setAddress("");

}
}